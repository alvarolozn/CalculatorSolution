package controller;

import java.util.ArrayList;
import model.History;
import model.Operation;

public class HistoryController {
    
    private final History history;

    public HistoryController(History history) {
        this.history = history;
    }

    public Response<ArrayList<Operation>> getHistory() {
        return new Response<>(200, "Success", history.getOperations());
    }

    public void addOperation(Operation operation) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
