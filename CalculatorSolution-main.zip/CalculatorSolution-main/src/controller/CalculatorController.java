package controller;

import java.util.ArrayList;
import model.Calculator;
import model.History;
import model.Operation;

public class CalculatorController {
    
    private final Calculator calculator;
    private final History history;

    public CalculatorController(Calculator calculator, History history) {
        this.calculator = calculator;
        this.history = history;
    }

    public Response<Double> add(double a, double b) {
        return performOperation(a, b, "add");
    }

    public Response<Double> subtract(double a, double b) {
        return performOperation(a, b, "subtract");
    }

    public Response<Double> multiply(double a, double b) {
        return performOperation(a, b, "multiply");
    }

    public Response<Double> divide(double a, double b) {
        if (b == 0) {
            return new Response<>(400, "Division by zero", null);
        }
        return performOperation(a, b, "divide");
    }

    private Response<Double> performOperation(double a, double b, String operation) {
        if (hasMoreThanThreeDecimalPlaces(a) || hasMoreThanThreeDecimalPlaces(b)) {
            return new Response<>(400, "Operands can have at most 3 decimal places", null);
        }

        double result;
        switch (operation) {
            case "add":
                result = calculator.add(a, b);
                break;
            case "subtract":
                result = calculator.subtract(a, b);
                break;
            case "multiply":
                result = calculator.multiply(a, b);
                break;
            case "divide":
                result = calculator.divide(a, b);
                break;
            default:
                return new Response<>(400, "Invalid operation", null);
        }

        if (hasMoreThanThreeDecimalPlaces(result)) {
            result = Math.round(result * 1000.0) / 1000.0;
        }

        history.addOperation(new Operation(a, b, getOperator(operation), result));
        return new Response<>(200, "Success", result);
    }

    private boolean hasMoreThanThreeDecimalPlaces(double value) {
        return Math.round(value * 1000.0) != value * 1000.0;
    }

    private String getOperator(String operation) {
        switch (operation) {
            case "add": return "+";
            case "subtract": return "-";
            case "multiply": return "*";
            case "divide": return "/";
            default: return "?";
        }
    }

    public Response<ArrayList<Operation>> getHistory() {
        return new Response<>(200, "Success", history.getOperations());
    }
}
