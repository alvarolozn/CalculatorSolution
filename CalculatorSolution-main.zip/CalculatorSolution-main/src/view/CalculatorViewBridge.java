package view;

import controller.CalculatorController;
import controller.HistoryController;
import controller.Response;
import model.Operation;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class CalculatorViewBridge {

    private final CalculatorController calculatorController;
    private final HistoryController historyController;

    public CalculatorViewBridge(CalculatorController calculatorController, HistoryController historyController) {
        this.calculatorController = calculatorController;
        this.historyController = historyController;
    }

    public void performAddition(double a, double b) {
        performOperation(a, b, "add");
    }

    public void performSubtraction(double a, double b) {
        performOperation(a, b, "subtract");
    }

    public void performMultiplication(double a, double b) {
        performOperation(a, b, "multiply");
    }

    public void performDivision(double a, double b) {
        performOperation(a, b, "divide");
    }
    
    public void performPower(double a, double b, double exponent) {
        Response<Double> response = calculatorController.power(a, b, exponent);
        handleOperationResponse(response, a, b, "^");
    }

    public void updateHistory() {
        Response<ArrayList<Operation>> response = historyController.getHistory();
        if (response.getStatusCode() == 200) {
            ArrayList<Operation> operations = response.getData();
            DefaultListModel model = new DefaultListModel();
            for (Operation operation : operations) {
                model.addElement(operation.toString());
            }
            CalculatorFrame.updateHistoryList(model); // Llamada al método en CalculatorFrame
        } else {
            JOptionPane.showMessageDialog(null, "Failed to retrieve history: " + response.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void performOperation(double a, double b, String operation) {
        Response<Double> response;
        switch (operation) {
            case "add":
                response = calculatorController.add(a, b);
                break;
            case "subtract":
                response = calculatorController.subtract(a, b);
                break;
            case "multiply":
                response = calculatorController.multiply(a, b);
                break;
            case "divide":
                response = calculatorController.divide(a, b);
                break;
            default:
                response = new Response<>(400, "Invalid operation", null);
                break;
        }
        handleOperationResponse(response, a, b, operation);
    }
    
    private void handleOperationResponse(Response<Double> response, double a, double b, String operation) {
        if (response.getStatusCode() == 200) {
            double result = response.getData();
            CalculatorFrame.updateResultField(String.valueOf(result));
            historyController.addOperation(new Operation(a, b, operation, result));
        } else {
            JOptionPane.showMessageDialog(null, "Operation failed: " + response.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
