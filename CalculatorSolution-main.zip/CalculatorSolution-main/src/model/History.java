package model;

import java.util.ArrayList;

public class History {
    
    private final ArrayList<Operation> operations;

    public History() {
        this.operations = new ArrayList<>();
    }
    
    public void addOperation(Operation operation) {
        this.operations.add(operation);
    }

    public ArrayList<Operation> getOperations() {
        return new ArrayList<>(operations);
    }
}
